package com.wildcodeschool.spring01;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@SpringBootApplication
public class Spring01Application {

	public static void main(String[] args) {
		SpringApplication.run(Spring01Application.class, args);
	}
// aus dem quest text:
// @RequestMapping("/")
// @ResponseBody
// public String index() {
//     return "Greetings from Spring Boot!";
	
@RequestMapping("/")
@ResponseBody
 public String index() {
     return "People who played the character of the Doctor! <br>" + "<ul>" + index2() +index3() + index4() + index5() + "</ul>"; 

	}

@RequestMapping("/Doctor/1")
@ResponseBody
	public String index2(){
		return
		"Doctor 1 <a href='https://en.wikipedia.org/wiki/William_Hartnell'>Wiliam Hartnell</a><br>";
	
	}


@RequestMapping("/Doctor/2")
@ResponseBody
	public String index3(){
		return
		"Doctor 2 <a href='https://en.wikipedia.org/wiki/Patrick_Troughton'>Patrick Troughton</a><br>";
	
	}

@RequestMapping("/Doctor/10")
@ResponseBody
	public String index4(){
		return
		"Doctor 10 <a href='https://en.wikipedia.org/wiki/David_Tennant'>David Tennant</a><br>";
		
		}
@RequestMapping("/Doctor/13")
@ResponseBody
	public String index5(){
		return
		"Doctor 13 <a href='https://en.wikipedia.org/wiki/Jodie_Whittaker'>Jodie Whittaker</a><br>";
	}

}
