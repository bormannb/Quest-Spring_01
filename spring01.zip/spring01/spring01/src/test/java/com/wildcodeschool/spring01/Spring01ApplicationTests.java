package com.wildcodeschool.spring01;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Spring01ApplicationTests {

	@Test
	void contextLoads() {
	}

}
